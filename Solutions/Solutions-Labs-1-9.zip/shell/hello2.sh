#!/bin/bash
MESSAGE="Hello World!"

echo $MESSAGE
