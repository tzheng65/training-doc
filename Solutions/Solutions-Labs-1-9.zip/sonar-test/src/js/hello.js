var a = 0;
b = 10;
