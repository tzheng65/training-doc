package "cowsay" do
 action :install
end


