package "cowsay" do
 action :install
end


package  'fortune'
package  'tree'

