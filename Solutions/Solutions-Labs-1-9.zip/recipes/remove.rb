package 'fortune' do
 action :remove
end

package 'cowsay' do
 action :remove
end

file '/tmp/hello.txt' do
 action :delete
end

