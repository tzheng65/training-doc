file '/tmp/hello.txt' do
 content 'Hello World!'
end

