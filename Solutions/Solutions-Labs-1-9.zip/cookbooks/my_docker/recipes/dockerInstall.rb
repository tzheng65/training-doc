#
# Cookbook Name:: my_docker
# Recipe:: dockerInstall
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
package 'docker-engine' do
 action :install
end

docker_service 'default' do
  action [:create, :start]
end
