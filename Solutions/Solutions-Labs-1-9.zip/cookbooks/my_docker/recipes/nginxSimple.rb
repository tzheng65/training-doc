#
# Cookbook Name:: my_docker
# Recipe:: nginxSimple
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
