#!/usr/bin/python
message = "Hello World!"
print message
