#!/usr/bin/python

import os

## display contents of /home/wasadmin folder
files = os.listdir("/home/wasadmin")

for f in files:
 print f

# create a list
dirs = []

# use 'while' loop to append more items to the list
counter = 1
while (counter <= 3):
 dirs.append("Item " +  str(counter))
 counter = counter + 1

# use 'for' loop to iterate over and display items
print "Display items using \"for\" loop"

for item in dirs:
 print item

# use 'for' loop to iterate by sequence index
print "Display items using sequence index"
for index in range(len(dirs)):
 print dirs[index]

# remove items by using 'for' loop
for item in dirs:
 dirs.remove(item)
