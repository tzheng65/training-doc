#!/usr/bin/python
import os
with open('/home/wasadmin/Documents/SimpleGreeting/pom.xml', 'r') as f:
        read_data= f.readline()
        counter = 1
        while (read_data ) :
                print read_data
                read_data = f.readline()
                counter = counter + 1
print counter
f.closed
