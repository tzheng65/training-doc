#!/bin/bash
# array and loops

# for loop with files / directories
echo -e "\e[31;43m FOR LOOP....\e[0m"
for FILE in /home/wasadmin/*
do
 echo -e "\e[28;33m $FILE  \e[0m"
done

DIRS[0]="TMP1"
DIRS[1]="TMP2"
DIRS[2]="TMP3"

# another for loop
# you can also use ${DIRS[@]} instead of ${DIRS[*]}
echo -e "\e[31;43m FOR LOOP....\e[0m"
for DIR in ${DIRS[*]}
do
 echo $DIR
done

# while loop
echo -e "\e[31;43m WHILE LOOP....\e[0m"
COUNTER=0
LENGTH=${#DIRS[*]}
echo $LENGTH
while [ $COUNTER -lt $LENGTH ]
do
 echo ${DIRS[$COUNTER]}
 # use back-quotes below 
 COUNTER=`expr $COUNTER + 1`
done

# until loop
echo -e "\e[31;43m UNTIL LOOP....\e[0m"
COUNTER=0

until [ ! $COUNTER -lt $LENGTH ]
do
 echo ${DIRS[$COUNTER] }
 COUNTER=`expr $COUNTER + 1`
done

# select loop
echo -e "\e[31;43m SELECT LOOP....\e[0m"

MENUS[0]="List"
MENUS[1]="Date"
MENUS[2]="Calendar"
MENUS[3]="Exit"

select MENU in ${MENUS[*]}
do
 case $MENU in
  List)
   echo 'Displaying directory contents...'
   ls
   ;;
  Date)
   echo 'Display date...'
   date
   ;;
  Calendar)
   echo 'Displaying calendar...'
   cal
   ;;
  Exit)
   break
   ;;
  *)
   echo 'ERROR: Invalid selection'
   ;;
 esac
done
