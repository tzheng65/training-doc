MESSAGE="Hello World!"

echo $MESSAGE
